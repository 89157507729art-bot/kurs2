<%@ Application Codebehind="Global.asax.cs" Inherits="KurkApteka.WebApi.WebApiApplication" Language="C#" %>
