using System;

namespace KurkApteka.WebApi.Models
{
    public class OrderDto
    {
        public int IdZakaza { get; set; }
        public DateTime DataSo creatingnya { get; set; }
        public decimal Summa { get; set; }
        public string Status { get; set; }
        public string Klient { get; set; }
    }
}
