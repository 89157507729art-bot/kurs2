using System;

namespace KurkApteka.WebApi.Models
{
    public class MedicineDto
    {
        public int Id { get; set; }
        public string Nazvanie { get; set; }
        public decimal Cena { get; set; }
        public int Kolichestvo { get; set; }
        public DateTime? SrokGodnosti { get; set; }
        public string Kategorija { get; set; }
        public string Razdel { get; set; }
        public string Proizvoditel { get; set; }
        public string Postavshik { get; set; }
        public string TipOtpuska { get; set; }
        public string PhotoPath { get; set; }
    }
}
