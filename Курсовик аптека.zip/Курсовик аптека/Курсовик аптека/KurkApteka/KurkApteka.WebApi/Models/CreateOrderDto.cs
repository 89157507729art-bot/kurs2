using System.Collections.Generic;

namespace KurkApteka.WebApi.Models
{
    public class CreateOrderDto
    {
        public int IdKlienta { get; set; }
        public List<OrderItemCreateDto> Items { get; set; }
    }

    public class OrderItemCreateDto
    {
        public int IdLekarstva { get; set; }
        public int Kolichestvo { get; set; }
    }
}
