namespace KurkApteka.WebApi.Models
{
    public class OrderItemDto
    {
        public string Nazvanie { get; set; }
        public int Kolichestvo { get; set; }
        public decimal Cena { get; set; }
        public decimal Suma { get; set; }
    }
}
