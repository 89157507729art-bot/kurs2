using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using KurkApteka.WebApi.Models;

namespace KurkApteka.WebApi.Controllers
{
    public class OrdersController : ApiController
    {
        private string ConnectionString =>
            ConfigurationManager.ConnectionStrings["AptekaDb"]?.ConnectionString ??
            @"Server=stud-mssql.sttec.yar.ru,38325;Database=user89_db;User Id=user89_db;Password=user89;";

        // GET api/orders?clientId=5
        [HttpGet]
        public IHttpActionResult GetByClient(int clientId)
        {
            var list = new List<OrderDto>();
            try
            {
                using (var con = new SqlConnection(ConnectionString))
                {
                    con.Open();
                    string sql = @"SELECT z.id_zakaza, z.data_sozdaniya, z.summa,
                                        ISNULL(s.Nazvanie, '') as Статус,
                                        p.Familiya + ' ' + p.Imya as Клиент
                                 FROM KURS_Zakazy z
                                 LEFT JOIN KURS_Status s ON z.id_statusa = s.id_statusa
                                 LEFT JOIN KURS_Polzovateli p ON z.id_klienta = p.id_polzovatelya
                                 WHERE z.id_klienta = @c
                                 ORDER BY z.id_zakaza DESC";
                    using (var cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@c", clientId);
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                list.Add(new OrderDto
                                {
                                    IdZakaza = (int)reader["id_zakaza"],
                                    DataSoCreatingnya = reader["data_sozdaniya"] == DBNull.Value ? DateTime.MinValue : (DateTime)reader["data_sozdaniya"],
                                    Summa = reader["summa"] == DBNull.Value ? 0 : (decimal)reader["summa"],
                                    Status = reader["Статус"].ToString(),
                                    Klient = reader["Клиент"].ToString()
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, new { error = ex.Message });
            }
            return Ok(list);
        }

        // GET api/orders/{id}/items
        [HttpGet]
        [Route("api/orders/{id}/items")]
        public IHttpActionResult GetItems(int id)
        {
            var items = new List<OrderItemDto>();
            try
            {
                using (var con = new SqlConnection(ConnectionString))
                {
                    con.Open();
                    string sql = @"SELECT l.Nazvanie, sz.Kolichestvo, sz.Cena_pri_zakaze,
                                        (sz.Kolichestvo * sz.Cena_pri_zakaze) as Suma
                                 FROM KURS_Sostav_zakaza sz
                                 JOIN KURS_Lekarstva l ON sz.id_lekarstva = l.id_lekarstva
                                 WHERE sz.id_zakaza = @id";
                    using (var cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                items.Add(new OrderItemDto
                                {
                                    Nazvanie = reader["Nazvanie"] == DBNull.Value ? "" : reader["Nazvanie"].ToString(),
                                    Kolichestvo = reader["Kolichestvo"] == DBNull.Value ? 0 : (int)reader["Kolichestvo"],
                                    Cena = reader["Cena_pri_zakaze"] == DBNull.Value ? 0 : (decimal)reader["Cena_pri_zakaze"],
                                    Suma = reader["Suma"] == DBNull.Value ? 0 : (decimal)reader["Suma"]
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, new { error = ex.Message });
            }
            return Ok(items);
        }

        // GET api/orders/{id}
        [HttpGet]
        public IHttpActionResult Get(int id)
        {
            try
            {
                using (var con = new SqlConnection(ConnectionString))
                {
                    con.Open();
                    string sql = @"SELECT z.id_zakaza, z.data_sozdaniya, z.summa,
                                        ISNULL(s.Nazvanie, '') as Статус
                                 FROM KURS_Zakazy z
                                 LEFT JOIN KURS_Status s ON z.id_statusa = s.id_statusa
                                 WHERE z.id_zakaza = @id";
                    using (var cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return Ok(new OrderDto
                                {
                                    IdZakaza = (int)reader["id_zakaza"],
                                    DataSoCreatingnya = reader["data_sozdaniya"] == DBNull.Value ? DateTime.MinValue : (DateTime)reader["data_sozdaniya"],
                                    Summa = reader["summa"] == DBNull.Value ? 0 : (decimal)reader["summa"],
                                    Status = reader["Статус"].ToString(),
                                    Klient = ""
                                });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, new { error = ex.Message });
            }
            return NotFound();
        }

        // POST api/orders
        [HttpPost]
        public IHttpActionResult Post([FromBody] CreateOrderDto dto)
        {
            if (dto == null || dto.Items == null || dto.Items.Count == 0)
                return BadRequest("Корзина пуста");

            decimal totalSum = 0;
            foreach (var item in dto.Items)
                totalSum += item.Cena * item.Kolichestvo;

            try
            {
                using (var con = new SqlConnection(ConnectionString))
                {
                    con.Open();
                    using (var tr = con.BeginTransaction())
                    {
                        try
                        {
                            // 1. Создаём заказ
                            var cmdOrder = new SqlCommand(
                                @"INSERT INTO KURS_Zakazy (id_klienta, id_farmacevta, data_sozdaniya, summa, id_statusa)
                                  OUTPUT INSERTED.id_zakaza
                                  VALUES (@c, NULL, GETDATE(), @s, 1)", con, tr);
                            cmdOrder.Parameters.AddWithValue("@c", dto.IdKlienta);
                            cmdOrder.Parameters.AddWithValue("@s", totalSum);
                            int newOrderId = (int)cmdOrder.ExecuteScalar();

                            // 2. Состав + списание остатков
                            foreach (var item in dto.Items)
                            {
                                var cmdItem = new SqlCommand(
                                    @"INSERT INTO KURS_Sostav_zakaza (id_zakaza, id_lekarstva, Kolichestvo, Cena_pri_zakaze)
                                      VALUES (@o, @m, @q, @p)", con, tr);
                                cmdItem.Parameters.AddWithValue("@o", newOrderId);
                                cmdItem.Parameters.AddWithValue("@m", item.IdLekarstva);
                                cmdItem.Parameters.AddWithValue("@q", item.Kolichestvo);
                                cmdItem.Parameters.AddWithValue("@p", item.Cena);
                                cmdItem.ExecuteNonQuery();

                                var cmdStock = new SqlCommand(
                                    "UPDATE KURS_Lekarstva SET Kolichestvo = Kolichestvo - @q WHERE id_lekarstva = @m",
                                    con, tr);
                                cmdStock.Parameters.AddWithValue("@q", item.Kolichestvo);
                                cmdStock.Parameters.AddWithValue("@m", item.IdLekarstva);
                                cmdStock.ExecuteNonQuery();
                            }

                            tr.Commit();
                            return Ok(new { idZakaza = newOrderId, summa = totalSum });
                        }
                        catch (Exception ex)
                        {
                            tr.Rollback();
                            return Content(HttpStatusCode.InternalServerError, new { error = ex.Message });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, new { error = ex.Message });
            }
        }
    }
}
