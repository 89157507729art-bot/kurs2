using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace KurkApteka.WebApi.Controllers
{
    public class StatusesController : ApiController
    {
        private string ConnectionString =>
            ConfigurationManager.ConnectionStrings["AptekaDb"]?.ConnectionString ??
            @"Server=stud-mssql.sttec.yar.ru,38325;Database=user89_db;User Id=user89_db;Password=user89;";

        // GET api/statuses
        [HttpGet]
        public IHttpActionResult Get()
        {
            var list = new List<dynamic>();
            try
            {
                using (var con = new SqlConnection(ConnectionString))
                {
                    con.Open();
                    using (var cmd = new SqlCommand("SELECT id_statusa, Nazvanie FROM KURS_Status", con))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(new
                            {
                                IdStatusa = (int)reader["id_statusa"],
                                Nazvanie = reader["Nazvanie"].ToString()
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, new { error = ex.Message });
            }
            return Ok(list);
        }
    }
}
