using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using KurkApteka.WebApi.Models;

namespace KurkApteka.WebApi.Controllers
{
    public class MedicinesController : ApiController
    {
        private string ConnectionString =>
            ConfigurationManager.ConnectionStrings["AptekaDb"]?.ConnectionString ??
            @"Server=stud-mssql.sttec.yar.ru,38325;Database=user89_db;User Id=user89_db;Password=user89;";

        // GET api/medicines
        [HttpGet]
        public IHttpActionResult Get()
        {
            var list = new List<MedicineDto>();
            try
            {
                using (var con = new SqlConnection(ConnectionString))
                {
                    con.Open();
                    string sql = @"SELECT l.id_lekarstva, l.Nazvanie, l.Cena, l.Kolichestvo, l.Srok_godnosti,
                                        ISNULL(k.Nazvanie, '') as Категория,
                                        ISNULL(r.Nazvanie, '') as Раздел,
                                        ISNULL(p.Nazvanie, '') as Производитель,
                                        ISNULL(s.Nazvanie, '') as Поставщик,
                                        ISNULL(t.Nazvanie, '') as ТипОтпуска,
                                        l.PhotoPath
                                 FROM KURS_Lekarstva l
                                 LEFT JOIN KURS_Kategorii k ON l.id_kategorii = k.id_kategorii
                                 LEFT JOIN KURS_Razdel r ON l.id_razdel = r.id_razdel
                                 LEFT JOIN KURS_Proizvoditeli p ON l.id_proizvoditelya = p.id_proizvoditelya
                                 LEFT JOIN KURS_Postavshiki s ON l.id_postavshika = s.id_postavshika
                                 LEFT JOIN KURS_Tip_otpuska t ON l.id_tipa_otpuska = t.id_tipa_otpuska";
                    using (var cmd = new SqlCommand(sql, con))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(new MedicineDto
                            {
                                Id = (int)reader["id_lekarstva"],
                                Nazvanie = reader["Nazvanie"] == DBNull.Value ? "" : reader["Nazvanie"].ToString(),
                                Cena = reader["Cena"] == DBNull.Value ? 0 : (decimal)reader["Cena"],
                                Kolichestvo = reader["Kolichestvo"] == DBNull.Value ? 0 : (int)reader["Kolichestvo"],
                                SrokGodnosti = reader["Srok_godnosti"] == DBNull.Value ? (DateTime?)null : (DateTime)reader["Srok_godnosti"],
                                Kategorija = reader["Категория"].ToString(),
                                Razdel = reader["Раздел"].ToString(),
                                Proizvoditel = reader["Производитель"].ToString(),
                                Postavshik = reader["Поставщик"].ToString(),
                                TipOtpuska = reader["ТипОтпуска"].ToString(),
                                PhotoPath = reader["PhotoPath"] == DBNull.Value ? "" : reader["PhotoPath"].ToString()
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, new { error = ex.Message });
            }
            return Ok(list);
        }

        // GET api/medicines/{id}
        [HttpGet]
        public IHttpActionResult Get(int id)
        {
            MedicineDto med = null;
            try
            {
                using (var con = new SqlConnection(ConnectionString))
                {
                    con.Open();
                    string sql = @"SELECT l.id_lekarstva, l.Nazvanie, l.Cena, l.Kolichestvo, l.Srok_godnosti,
                                        ISNULL(k.Nazvanie, '') as Категория,
                                        ISNULL(r.Nazvanie, '') as Раздел,
                                        ISNULL(p.Nazvanie, '') as Производитель,
                                        ISNULL(s.Nazvanie, '') as Поставщик,
                                        ISNULL(t.Nazvanie, '') as ТипОтпуска,
                                        l.PhotoPath
                                 FROM KURS_Lekarstva l
                                 LEFT JOIN KURS_Kategorii k ON l.id_kategorii = k.id_kategorii
                                 LEFT JOIN KURS_Razdel r ON l.id_razdel = r.id_razdel
                                 LEFT JOIN KURS_Proizvoditeli p ON l.id_proizvoditelya = p.id_proizvoditelya
                                 LEFT JOIN KURS_Postavshiki s ON l.id_postavshika = s.id_postavshika
                                 LEFT JOIN KURS_Tip_otpuska t ON l.id_tipa_otpuska = t.id_tipa_otpuska
                                 WHERE l.id_lekarstva = @id";
                    using (var cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                med = new MedicineDto
                                {
                                    Id = (int)reader["id_lekarstva"],
                                    Nazvanie = reader["Nazvanie"] == DBNull.Value ? "" : reader["Nazvanie"].ToString(),
                                    Cena = reader["Cena"] == DBNull.Value ? 0 : (decimal)reader["Cena"],
                                    Kolichestvo = reader["Kolichestvo"] == DBNull.Value ? 0 : (int)reader["Kolichestvo"],
                                    SrokGodnosti = reader["Srok_godnosti"] == DBNull.Value ? (DateTime?)null : (DateTime)reader["Srok_godnosti"],
                                    Kategorija = reader["Категория"].ToString(),
                                    Razdel = reader["Раздел"].ToString(),
                                    Proizvoditel = reader["Производитель"].ToString(),
                                    Postavshik = reader["Поставщик"].ToString(),
                                    TipOtpuska = reader["ТипОтпуска"].ToString(),
                                    PhotoPath = reader["PhotoPath"] == DBNull.Value ? "" : reader["PhotoPath"].ToString()
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.InternalServerError, new { error = ex.Message });
            }
            if (med == null) return NotFound();
            return Ok(med);
        }
    }
}
