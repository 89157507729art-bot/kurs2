﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace KurkApteka
{
    public partial class EmployeeWin : Window
    {
        string ConnectString = DbHelper.ConnectionString;
        int userId = 0;

        // Простая корзина (чех) без отдельного класса
        List<int> cartIds = new List<int>();
        List<string> cartNames = new List<string>();
        List<decimal> cartPrices = new List<decimal>();
        List<int> cartQtys = new List<int>();

        public EmployeeWin(int id)
        {
            InitializeComponent();
            userId = id;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadFio();
            LoadStatuses();
            LoadClients();
            LoadOrders();
            LoadCatalog();
        }

        void LoadFio()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("SELECT Familiya + ' ' + Imya FROM KURS_Polzovateli WHERE id_polzovatelya=@id", con);
                    cmd.Parameters.AddWithValue("@id", userId);
                    object res = cmd.ExecuteScalar();
                    LblFio.Text = res == null ? "" : res.ToString();
                }
            }
            catch { }
        }

        void LoadStatuses()
        {
            using (SqlConnection con = new SqlConnection(ConnectString))
            {
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT id_statusa, Nazvanie FROM KURS_Status", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                CbStatus.ItemsSource = dt.DefaultView;
            }
        }

        // ================= ВКЛАДКА 1: ЗАКАЗЫ =================
        void LoadOrders()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string query = @"SELECT z.id_zakaza, z.data_sozdaniya, z.summa, s.Nazvanie as Status, 
                                            p.Familiya + ' ' + p.Imya as Klient
                                     FROM KURS_Zakazy z
                                     LEFT JOIN KURS_Status s ON z.id_statusa = s.id_statusa
                                     LEFT JOIN KURS_Polzovateli p ON z.id_klienta = p.id_polzovatelya
                                     ORDER BY z.id_zakaza DESC";
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    DgOrders.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        int GetStatusIdByName(string name)
        {
            using (var con = new SqlConnection(ConnectString))
            {
                con.Open();
                var cmd = new SqlCommand("SELECT id_statusa FROM KURS_Status WHERE Nazvanie=@n", con);
                cmd.Parameters.AddWithValue("@n", name);
                var res = cmd.ExecuteScalar();
                return res == null ? -1 : (int)res;
            }
        }

        // Вернуть остатки на склад по позициям заказа
        void ReturnOrderStock(int orderId)
        {
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    var cmdItems = new SqlCommand(
                        "SELECT id_lekarstva, Kolichestvo FROM KURS_Sostav_zakaza WHERE id_zakaza=@id", con);
                    cmdItems.Parameters.AddWithValue("@id", orderId);
                    using (var reader = cmdItems.ExecuteReader())
                    {
                        var medIds = new List<int>();
                        var qtys = new List<int>();
                        while (reader.Read())
                        {
                            medIds.Add((int)reader["id_lekarstva"]);
                            qtys.Add((int)reader["Kolichestvo"]);
                        }
                        reader.Close();

                        for (int i = 0; i < medIds.Count; i++)
                        {
                            var cmd = new SqlCommand(
                                "UPDATE KURS_Lekarstva SET Kolichestvo = Kolichestvo + @q WHERE id_lekarstva = @id",
                                con);
                            cmd.Parameters.AddWithValue("@q", qtys[i]);
                            cmd.Parameters.AddWithValue("@id", medIds[i]);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show("Ошибка возврата остатков: " + ex.Message); }
        }

        // Снять остатки со склада (при повторном оформлении после отмены)
        void DeductOrderStock(int orderId)
        {
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    var cmdItems = new SqlCommand(
                        "SELECT id_lekarstva, Kolichestvo FROM KURS_Sostav_zakaza WHERE id_zakaza=@id", con);
                    cmdItems.Parameters.AddWithValue("@id", orderId);
                    using (var reader = cmdItems.ExecuteReader())
                    {
                        var medIds = new List<int>();
                        var qtys = new List<int>();
                        while (reader.Read())
                        {
                            medIds.Add((int)reader["id_lekarstva"]);
                            qtys.Add((int)reader["Kolichestvo"]);
                        }
                        reader.Close();

                        for (int i = 0; i < medIds.Count; i++)
                        {
                            var cmd = new SqlCommand(
                                "UPDATE KURS_Lekarstva SET Kolichestvo = Kolichestvo - @q WHERE id_lekarstva = @id",
                                con);
                            cmd.Parameters.AddWithValue("@q", qtys[i]);
                            cmd.Parameters.AddWithValue("@id", medIds[i]);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show("Ошибка списания остатков: " + ex.Message); }
        }

        private void BtnRefreshOrders_Click(object sender, RoutedEventArgs e)
        {
            LoadOrders();
        }

        private void TbSearchOrder_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DgOrders.ItemsSource == null) return;
            DataView dv = (DataView)DgOrders.ItemsSource;
            string search = TbSearchOrder.Text.Trim().Replace("'", "''");
            dv.RowFilter = search == "" ? "" : "Klient LIKE '%" + search + "%' OR id_zakaza LIKE '%" + search + "%'";
        }

        private void BtnChangeStatus_Click(object sender, RoutedEventArgs e)
        {
            if (DgOrders.SelectedItem == null) { MessageBox.Show("Выберите заказ!"); return; }
            if (CbStatus.SelectedValue == null) { MessageBox.Show("Выберите статус!"); return; }

            int orderId = (int)((DataRowView)DgOrders.SelectedItem)["id_zakaza"];
            int newStatusId = (int)CbStatus.SelectedValue;

            // Получаем старый статус из строки
            var row = (DataRowView)DgOrders.SelectedItem;
            string oldStatusName = row["Status"] == DBNull.Value ? "" : row["Status"].ToString();

            int cancelledStatusId = GetStatusIdByName("Отменён");

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE KURS_Zakazy SET id_statusa=@s WHERE id_zakaza=@id", con);
                    cmd.Parameters.AddWithValue("@s", newStatusId);
                    cmd.Parameters.AddWithValue("@id", orderId);
                    cmd.ExecuteNonQuery();
                }

                // Если новый статус = Отменён, а старый не Отменён — возвращаем остатки
                if (cancelledStatusId > 0 && newStatusId == cancelledStatusId && oldStatusName != "Отменён")
                {
                    ReturnOrderStock(orderId);
                }
                // Если старый статус = Отменён, а новый не Отменён — списываем остатки снова
                else if (cancelledStatusId > 0 && oldStatusName == "Отменён" && newStatusId != cancelledStatusId)
                {
                    DeductOrderStock(orderId);
                }

                LoadOrders();
                MessageBox.Show("Статус обновлен!");
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnViewOrderItems_Click(object sender, RoutedEventArgs e)
        {
            if (DgOrders.SelectedItem == null) { MessageBox.Show("Выберите заказ!"); return; }
            int orderId = (int)((DataRowView)DgOrders.SelectedItem)["id_zakaza"];

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string query = @"SELECT l.Nazvanie, sz.Kolichestvo, sz.Cena_pri_zakaze, (sz.Kolichestvo * sz.Cena_pri_zakaze) as Summa
                                     FROM KURS_Sostav_zakaza sz
                                     JOIN KURS_Lekarstva l ON sz.id_lekarstva = l.id_lekarstva
                                     WHERE sz.id_zakaza = @id";
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    da.SelectCommand.Parameters.AddWithValue("@id", orderId);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    string msg = "Состав заказа:\n\n";
                    foreach (DataRow dr in dt.Rows)
                        msg += "- " + dr["Nazvanie"] + " x" + dr["Kolichestvo"] + " = " + dr["Summa"] + " ₽\n";

                    MessageBox.Show(msg, "Состав заказа");
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        // ================= ВКЛАДКА 2: СОЗДАНИЕ ЗАКАЗА =================
        void LoadClients()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter("SELECT id_polzovatelya, Familiya + ' ' + Imya as KlientName FROM KURS_Polzovateli WHERE id_roli = 3", con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    CbClient.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        void LoadCatalog()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string query = @"SELECT l.id_lekarstva, l.Nazvanie, l.Cena, l.Kolichestvo
                                     FROM KURS_Lekarstva l";
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    DgCatalog.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void TbSearchMed_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DgCatalog.ItemsSource == null) return;
            DataView dv = (DataView)DgCatalog.ItemsSource;
            string search = TbSearchMed.Text.Trim().Replace("'", "''");
            dv.RowFilter = search == "" ? "" : "Nazvanie LIKE '%" + search + "%'";
        }

        // Двойной клик по лекарству добавляет его в чек
        private void DgCatalog_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (DgCatalog.SelectedItem is DataRowView)
            {
                DataRowView row = (DataRowView)DgCatalog.SelectedItem;
                int id = (int)row["id_lekarstva"];
                string name = row["Nazvanie"].ToString();
                decimal price = (decimal)row["Cena"];
                int stock = (int)row["Kolichestvo"];

                if (stock <= 0) { MessageBox.Show("Нет в наличии!"); return; }

                int idx = cartIds.IndexOf(id);
                if (idx >= 0)
                {
                    if (cartQtys[idx] < stock) cartQtys[idx]++;
                    else MessageBox.Show("Достигнут лимит остатков на складе!");
                }
                else
                {
                    cartIds.Add(id);
                    cartNames.Add(name);
                    cartPrices.Add(price);
                    cartQtys.Add(1);
                }

                UpdateCartGrid();
            }
        }

        void UpdateCartGrid()
        {
            DgCart.ItemsSource = null;
            var items = new List<dynamic>();
            decimal total = 0;
            for (int i = 0; i < cartIds.Count; i++)
            {
                decimal itemTotal = cartPrices[i] * cartQtys[i];
                total += itemTotal;
                items.Add(new
                {
                    Nazvanie = cartNames[i],
                    Quantity = cartQtys[i],
                    Total = itemTotal
                });
            }
            DgCart.ItemsSource = items;
            LblTotalPrice.Text = total.ToString("N2") + " ₽";
        }

        private void BtnCreateOrder_Click(object sender, RoutedEventArgs e)
        {
            if (CbClient.SelectedValue == null) { MessageBox.Show("Выберите клиента!"); return; }
            if (cartIds.Count == 0) { MessageBox.Show("Чек пуст!"); return; }

            int clientId = (int)CbClient.SelectedValue;
            decimal totalSum = 0;
            for (int i = 0; i < cartIds.Count; i++)
                totalSum += cartPrices[i] * cartQtys[i];

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    SqlTransaction tr = con.BeginTransaction();
                    try
                    {
                        SqlCommand cmdOrder = new SqlCommand(
                            @"INSERT INTO KURS_Zakazy (id_klienta, id_farmacevta, data_sozdaniya, summa, id_statusa) 
                              OUTPUT INSERTED.id_zakaza 
                              VALUES (@c, @f, GETDATE(), @s, 1)", con, tr);
                        cmdOrder.Parameters.AddWithValue("@c", clientId);
                        cmdOrder.Parameters.AddWithValue("@f", userId);
                        cmdOrder.Parameters.AddWithValue("@s", totalSum);

                        int newOrderId = (int)cmdOrder.ExecuteScalar();

                        for (int i = 0; i < cartIds.Count; i++)
                        {
                            SqlCommand cmdItem = new SqlCommand(
                                @"INSERT INTO KURS_Sostav_zakaza (id_zakaza, id_lekarstva, Kolichestvo, Cena_pri_zakaze) 
                                  VALUES (@o, @m, @q, @p)", con, tr);
                            cmdItem.Parameters.AddWithValue("@o", newOrderId);
                            cmdItem.Parameters.AddWithValue("@m", cartIds[i]);
                            cmdItem.Parameters.AddWithValue("@q", cartQtys[i]);
                            cmdItem.Parameters.AddWithValue("@p", cartPrices[i]);
                            cmdItem.ExecuteNonQuery();

                            SqlCommand cmdStock = new SqlCommand(
                                "UPDATE KURS_Lekarstva SET Kolichestvo = Kolichestvo - @q WHERE id_lekarstva = @m", con, tr);
                            cmdStock.Parameters.AddWithValue("@q", cartQtys[i]);
                            cmdStock.Parameters.AddWithValue("@m", cartIds[i]);
                            cmdStock.ExecuteNonQuery();
                        }

                        tr.Commit();
                        MessageBox.Show("Заказ №" + newOrderId + " успешно оформлен!");

                        cartIds.Clear();
                        cartNames.Clear();
                        cartPrices.Clear();
                        cartQtys.Clear();
                        UpdateCartGrid();
                        CbClient.SelectedIndex = -1;
                        LoadOrders();
                        LoadCatalog();
                    }
                    catch (Exception ex)
                    {
                        tr.Rollback();
                        throw new Exception("Ошибка при сохранении: " + ex.Message);
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            this.Close();
        }

        private void DgOrders_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
