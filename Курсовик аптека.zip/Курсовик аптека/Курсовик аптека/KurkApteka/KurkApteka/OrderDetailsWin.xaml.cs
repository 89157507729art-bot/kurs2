using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace KurkApteka
{
    public partial class OrderDetailsWin : Window
    {
        int orderId;
        string ConnectString = DbHelper.ConnectionString;

        public OrderDetailsWin(int orderId, string orderDate, decimal totalSum)
        {
            InitializeComponent();
            this.orderId = orderId;
            TbOrderInfo.Text = "Заказ №" + orderId + " от " + orderDate;
            LblOrderTotal.Text = totalSum.ToString("N2") + " ₽";
            LoadItems();
        }

        void LoadItems()
        {
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string sql = @"SELECT l.Nazvanie, sz.Kolichestvo, sz.Cena_pri_zakaze,
                                          (sz.Kolichestvo * sz.Cena_pri_zakaze) as Suma
                                   FROM KURS_Sostav_zakaza sz
                                   JOIN KURS_Lekarstva l ON sz.id_lekarstva = l.id_lekarstva
                                   WHERE sz.id_zakaza = @id
                                   ORDER BY l.Nazvanie";
                    var cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@id", orderId);
                    var da = new SqlDataAdapter(cmd);
                    var dt = new DataTable();
                    da.Fill(dt);
                    DgItems.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }
}
