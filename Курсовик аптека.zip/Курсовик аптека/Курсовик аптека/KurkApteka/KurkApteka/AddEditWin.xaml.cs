using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace KurkApteka
{
    public partial class AddEditWin : Window
    {
        string ConnectString = DbHelper.ConnectionString;
        string table;
        string pk;
        object pkValue;
        List<FieldDef> fields;
        Dictionary<string, DataTable> fkCache;

        List<Control> fieldControls = new List<Control>(); // TextBox или ComboBox

        public AddEditWin(string table, string pk, object pkValue, List<FieldDef> fields, Dictionary<string, DataTable> fkCache)
        {
            InitializeComponent();
            this.table = table;
            this.pk = pk;
            this.pkValue = pkValue;
            this.fields = fields;
            this.fkCache = fkCache;
            BuildForm();
            if (pkValue != null) LoadValues();
        }

        void BuildForm()
        {
            foreach (var field in fields)
            {
                var lbl = new Label { Content = field.Label, Margin = new Thickness(0, 8, 0, 2) };

                Control ctrl;
                if (field.IsForeignKey)
                {
                    var cb = new ComboBox
                    {
                        Margin = new Thickness(0, 0, 0, 8),
                        DisplayMemberPath = field.FkDisplayColumn,
                        SelectedValuePath = field.FkValueColumn,
                        MinHeight = 30
                    };
                    LoadFkComboBox(cb, field);
                    ctrl = cb;
                }
                else
                {
                    ctrl = new TextBox { Margin = new Thickness(0, 0, 0, 8), MinHeight = 30 };
                }

                fieldControls.Add(ctrl);
                SpForm.Children.Add(lbl);
                SpForm.Children.Add(ctrl);
            }
        }

        void LoadFkComboBox(ComboBox cb, FieldDef field)
        {
            var dt = GetFkTable(field.FkTable);
            if (dt != null)
            {
                cb.ItemsSource = dt.DefaultView;
            }
        }

        DataTable GetFkTable(string tableName)
        {
            if (fkCache != null && fkCache.ContainsKey(tableName))
                return fkCache[tableName];

            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    var da = new SqlDataAdapter("SELECT * FROM " + tableName, con);
                    var dt = new DataTable();
                    da.Fill(dt);
                    if (fkCache != null) fkCache[tableName] = dt;
                    return dt;
                }
            }
            catch { return null; }
        }

        void LoadValues()
        {
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string sql = "SELECT * FROM " + table + " WHERE " + pk + "=@id";
                    using (var cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@id", pkValue);
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                for (int i = 0; i < fields.Count; i++)
                                {
                                    var val = reader[fields[i].DbName];
                                    if (val == DBNull.Value) continue;

                                    if (fields[i].IsForeignKey)
                                    {
                                        var cb = fieldControls[i] as ComboBox;
                                        if (cb != null) cb.SelectedValue = val;
                                    }
                                    else
                                    {
                                        var tb = fieldControls[i] as TextBox;
                                        if (tb != null) tb.Text = val.ToString();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string cmdText;
                    if (pkValue == null)
                    {
                        var colsList = new List<string>();
                        var valsList = new List<string>();
                        foreach (var f in fields)
                        {
                            colsList.Add(f.DbName);
                            valsList.Add("@" + f.DbName);
                        }
                        string cols = string.Join(", ", colsList.ToArray());
                        string vals = string.Join(", ", valsList.ToArray());
                        cmdText = "INSERT INTO " + table + " (" + cols + ") VALUES (" + vals + ")";
                    }
                    else
                    {
                        var sets = new List<string>();
                        foreach (var f in fields) sets.Add(f.DbName + "=@" + f.DbName);
                        cmdText = "UPDATE " + table + " SET " + string.Join(", ", sets.ToArray()) + " WHERE " + pk + "=@pk";
                    }

                    using (var cmd = new SqlCommand(cmdText, con))
                    {
                        for (int i = 0; i < fields.Count; i++)
                        {
                            object val;
                            if (fields[i].IsForeignKey)
                            {
                                var cb = fieldControls[i] as ComboBox;
                                val = cb != null ? cb.SelectedValue : DBNull.Value;
                            }
                            else
                            {
                                var tb = fieldControls[i] as TextBox;
                                if (tb != null)
                                    val = string.IsNullOrWhiteSpace(tb.Text) ? (object)DBNull.Value : tb.Text;
                                else
                                    val = DBNull.Value;
                            }
                            cmd.Parameters.AddWithValue("@" + fields[i].DbName, val);
                        }
                        if (pkValue != null) cmd.Parameters.AddWithValue("@pk", pkValue);
                        cmd.ExecuteNonQuery();
                    }
                }
                DialogResult = true;
                Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
