﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace KurkApteka
{
    public class FieldDef
    {
        public string DbName;
        public string Label;
        public bool IsForeignKey;
        public string FkTable;
        public string FkValueColumn;
        public string FkDisplayColumn;
    }

    public partial class AdminWin : Window
    {
        string ConnectString = DbHelper.ConnectionString;
        string currentTable = "";
        string currentPk = "";
        List<FieldDef> currentFields = new List<FieldDef>();

        Dictionary<string, DataTable> fkCache = new Dictionary<string, DataTable>();

        public AdminWin()
        {
            InitializeComponent();
            LoadMenu();
            if (LbTables.Items.Count > 0) LbTables.SelectedIndex = 0;
        }

        void LoadMenu()
        {
            var items = new List<dynamic>
            {
                new { Nazvanie = "Лекарства", Table = "KURS_Lekarstva", Pk = "id_lekarstva" },
                new { Nazvanie = "Категории", Table = "KURS_Kategorii", Pk = "id_kategorii" },
                new { Nazvanie = "Разделы", Table = "KURS_Razdel", Pk = "id_razdel" },
                new { Nazvanie = "Производители", Table = "KURS_Proizvoditeli", Pk = "id_proizvoditelya" },
                new { Nazvanie = "Поставщики", Table = "KURS_Postavshiki", Pk = "id_postavshika" },
                new { Nazvanie = "Пользователи", Table = "KURS_Polzovateli", Pk = "id_polzovatelya" },
                new { Nazvanie = "Заказы", Table = "KURS_Zakazy", Pk = "id_zakaza" },
                new { Nazvanie = "Статусы", Table = "KURS_Status", Pk = "id_statusa" },
            };
            LbTables.ItemsSource = items;
        }

        private void LbTables_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (LbTables.SelectedItem == null) return;
            dynamic item = LbTables.SelectedItem;
            currentTable = item.Table;
            currentPk = item.Pk;

            TbTabTitle.Text = item.Nazvanie;
            BorderReport.Visibility = (item.Table == "KURS_Zakazy") ? Visibility.Visible : Visibility.Collapsed;

            currentFields = GetFieldDefs(currentTable);
            LoadData(currentTable);
        }

        List<FieldDef> GetFieldDefs(string table)
        {
            var f = new List<FieldDef>();
            switch (table)
            {
                case "KURS_Lekarstva":
                    f.Add(new FieldDef { DbName = "Nazvanie", Label = "Название" });
                    f.Add(new FieldDef { DbName = "Cena", Label = "Цена" });
                    f.Add(new FieldDef { DbName = "Kolichestvo", Label = "Количество" });
                    f.Add(new FieldDef { DbName = "Srok_godnosti", Label = "Срок годности" });
                    f.Add(new FieldDef { DbName = "id_kategorii", Label = "Категория", IsForeignKey = true, FkTable = "KURS_Kategorii", FkValueColumn = "id_kategorii", FkDisplayColumn = "Nazvanie" });
                    f.Add(new FieldDef { DbName = "id_razdel", Label = "Раздел", IsForeignKey = true, FkTable = "KURS_Razdel", FkValueColumn = "id_razdel", FkDisplayColumn = "Nazvanie" });
                    f.Add(new FieldDef { DbName = "id_proizvoditelya", Label = "Производитель", IsForeignKey = true, FkTable = "KURS_Proizvoditeli", FkValueColumn = "id_proizvoditelya", FkDisplayColumn = "Nazvanie" });
                    f.Add(new FieldDef { DbName = "id_postavshika", Label = "Поставщик", IsForeignKey = true, FkTable = "KURS_Postavshiki", FkValueColumn = "id_postavshika", FkDisplayColumn = "Nazvanie_organizacii" });
                    f.Add(new FieldDef { DbName = "id_tipa_otpuska", Label = "Тип отпуска", IsForeignKey = true, FkTable = "KURS_Tip_otpuska", FkValueColumn = "id_tipa_otpuska", FkDisplayColumn = "Nazvanie" });
                    f.Add(new FieldDef { DbName = "PhotoPath", Label = "Путь к фото" });
                    break;
                case "KURS_Kategorii":
                    f.Add(new FieldDef { DbName = "Nazvanie", Label = "Название" });
                    f.Add(new FieldDef { DbName = "id_razdel", Label = "Раздел", IsForeignKey = true, FkTable = "KURS_Razdel", FkValueColumn = "id_razdel", FkDisplayColumn = "Nazvanie" });
                    break;
                case "KURS_Razdel":
                    f.Add(new FieldDef { DbName = "Nazvanie", Label = "Название" });
                    break;
                case "KURS_Proizvoditeli":
                    f.Add(new FieldDef { DbName = "Nazvanie", Label = "Название" });
                    f.Add(new FieldDef { DbName = "Strana", Label = "Страна" });
                    break;
                case "KURS_Postavshiki":
                    f.Add(new FieldDef { DbName = "Nazvanie_organizacii", Label = "Название организации" });
                    f.Add(new FieldDef { DbName = "Telefon", Label = "Телефон" });
                    f.Add(new FieldDef { DbName = "Adres", Label = "Адрес" });
                    f.Add(new FieldDef { DbName = "INN", Label = "ИНН" });
                    break;
                case "KURS_Polzovateli":
                    f.Add(new FieldDef { DbName = "id_roli", Label = "Роль", IsForeignKey = true, FkTable = "KURS_Roli", FkValueColumn = "id_roli", FkDisplayColumn = "Nazvanie" });
                    f.Add(new FieldDef { DbName = "Login", Label = "Логин" });
                    f.Add(new FieldDef { DbName = "Parol", Label = "Пароль" });
                    f.Add(new FieldDef { DbName = "Telefon", Label = "Телефон" });
                    f.Add(new FieldDef { DbName = "email", Label = "Email" });
                    f.Add(new FieldDef { DbName = "adres", Label = "Адрес" });
                    f.Add(new FieldDef { DbName = "Familiya", Label = "Фамилия" });
                    f.Add(new FieldDef { DbName = "Imya", Label = "Имя" });
                    f.Add(new FieldDef { DbName = "Otchestvo", Label = "Отчество" });
                    break;
                case "KURS_Zakazy":
                    f.Add(new FieldDef { DbName = "id_klienta", Label = "Клиент", IsForeignKey = true, FkTable = "KURS_Polzovateli", FkValueColumn = "id_polzovatelya", FkDisplayColumn = "Familiya" });
                    f.Add(new FieldDef { DbName = "id_farmacevta", Label = "Фармацевт", IsForeignKey = true, FkTable = "KURS_Polzovateli", FkValueColumn = "id_polzovatelya", FkDisplayColumn = "Familiya" });
                    f.Add(new FieldDef { DbName = "summa", Label = "Сумма" });
                    f.Add(new FieldDef { DbName = "id_statusa", Label = "Статус", IsForeignKey = true, FkTable = "KURS_Status", FkValueColumn = "id_statusa", FkDisplayColumn = "Nazvanie" });
                    break;
                case "KURS_Status":
                    f.Add(new FieldDef { DbName = "Nazvanie", Label = "Название" });
                    break;
            }
            return f;
        }

        string GetSelectSql(string table)
        {
            switch (table)
            {
                case "KURS_Lekarstva":
                    return @"SELECT l.id_lekarstva as id_lekarstva, l.Nazvanie as Название, l.Cena as Цена,
                                    l.Kolichestvo as Количество, l.Srok_godnosti as СрокГодности,
                                    (SELECT ISNULL(k.Nazvanie, '') FROM KURS_Kategorii k WHERE k.id_kategorii = l.id_kategorii) as Категория,
                                    (SELECT ISNULL(r.Nazvanie, '') FROM KURS_Razdel r WHERE r.id_razdel = l.id_razdel) as Раздел,
                                    (SELECT ISNULL(p.Nazvanie, '') FROM KURS_Proizvoditeli p WHERE p.id_proizvoditelya = l.id_proizvoditelya) as Производитель,
                                    (SELECT ISNULL(s.Nazvanie_organizacii, '') FROM KURS_Postavshiki s WHERE s.id_postavshika = l.id_postavshika) as Поставщик,
                                    (SELECT ISNULL(t.Nazvanie, '') FROM KURS_Tip_otpuska t WHERE t.id_tipa_otpuska = l.id_tipa_otpuska) as ТипОтпуска,
                                    l.PhotoPath as ПутьКФото
                             FROM KURS_Lekarstva l";
                case "KURS_Kategorii":
                    return @"SELECT k.id_kategorii as id_kategorii, k.Nazvanie as Название,
                                    (SELECT ISNULL(r.Nazvanie, '') FROM KURS_Razdel r WHERE r.id_razdel = k.id_razdel) as Раздел
                             FROM KURS_Kategorii k";
                case "KURS_Razdel":
                    return "SELECT id_razdel as id_razdel, Nazvanie as Название FROM KURS_Razdel";
                case "KURS_Proizvoditeli":
                    return "SELECT id_proizvoditelya as id_proizvoditelya, Nazvanie as Название, Strana as Страна FROM KURS_Proizvoditeli";
                case "KURS_Postavshiki":
                    return "SELECT id_postavshika as id_postavshika, Nazvanie_organizacii as НазваниеОрганизации, Telefon as Телефон, Adres as Адрес, INN as ИНН FROM KURS_Postavshiki";
                case "KURS_Polzovateli":
                    return @"SELECT p.id_polzovatelya as id_polzovatelya,
                                    (SELECT ISNULL(r.Nazvanie, '') FROM KURS_Roli r WHERE r.id_roli = p.id_roli) as Роль,
                                    p.Login as Логин, p.Parol as Пароль, p.Telefon as Телефон,
                                    p.email as Email, p.adres as Адрес, p.Familiya as Фамилия,
                                    p.Imya as Имя, p.Otchestvo as Отчество
                             FROM KURS_Polzovateli p";
                case "KURS_Zakazy":
                    return @"SELECT z.id_zakaza as id_zakaza, z.data_sozdaniya as Дата,
                                    (SELECT kl.Familiya + ' ' + kl.Imya FROM KURS_Polzovateli kl WHERE kl.id_polzovatelya = z.id_klienta) as Клиент,
                                    (SELECT fa.Familiya + ' ' + fa.Imya FROM KURS_Polzovateli fa WHERE fa.id_polzovatelya = z.id_farmacevta) as Фармацевт,
                                    z.summa as Сумма,
                                    (SELECT ISNULL(s.Nazvanie, '') FROM KURS_Status s WHERE s.id_statusa = z.id_statusa) as Статус
                             FROM KURS_Zakazy z";
                case "KURS_Status":
                    return "SELECT id_statusa as id_statusa, Nazvanie as Название FROM KURS_Status";
                default:
                    return "SELECT * FROM " + table;
            }
        }

        void LoadData(string table)
        {
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string sql = GetSelectSql(table);
                    var da = new SqlDataAdapter(sql, con);
                    var dt = new DataTable();
                    da.Fill(dt);
                    DgMain.ItemsSource = dt.DefaultView;

                    DgMain.Columns.Clear();
                    foreach (DataColumn col in dt.Columns)
                    {
                        DgMain.Columns.Add(new DataGridTextColumn
                        {
                            Header = col.ColumnName,
                            Binding = new System.Windows.Data.Binding("[" + col.ColumnName + "]")
                        });
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadData(currentTable);
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (DgMain.SelectedItem == null) { MessageBox.Show("Выберите строку!"); return; }
            var row = (DataRowView)DgMain.SelectedItem;
            if (row == null) return;

            if (!row.Row.Table.Columns.Contains(currentPk))
            {
                MessageBox.Show("Колонка '" + currentPk + "' не найдена в данных.");
                return;
            }

            object pkVal = row[currentPk];

            // Если удаляем заказ — сначала возвращаем остатки на склад
            if (currentTable == "KURS_Zakazy")
            {
                ReturnOrderStock((int)pkVal);
            }

            if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButton.YesNo) != MessageBoxResult.Yes)
                return;

            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    var cmd = new SqlCommand("DELETE FROM " + currentTable + " WHERE " + currentPk + "=@id", con);
                    cmd.Parameters.AddWithValue("@id", pkVal);
                    cmd.ExecuteNonQuery();
                }
                LoadData(currentTable);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            var win = new AddEditWin(currentTable, currentPk, null, currentFields, fkCache);
            if (win.ShowDialog() == true) LoadData(currentTable);
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (DgMain.SelectedItem == null) { MessageBox.Show("Выберите строку для редактирования!"); return; }
            var row = (DataRowView)DgMain.SelectedItem;
            if (row == null) return;

            if (!row.Row.Table.Columns.Contains(currentPk))
            {
                MessageBox.Show("Колонка '" + currentPk + "' не найдена в данных.");
                return;
            }

            object pkValue = row[currentPk];
            var win = new AddEditWin(currentTable, currentPk, pkValue, currentFields, fkCache);
            if (win.ShowDialog() == true) LoadData(currentTable);
        }

        DataTable GetFkTable(string tableName)
        {
            if (fkCache.ContainsKey(tableName)) return fkCache[tableName];

            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string sql = "SELECT * FROM " + tableName;
                    var da = new SqlDataAdapter(sql, con);
                    var dt = new DataTable();
                    da.Fill(dt);
                    fkCache[tableName] = dt;
                    return dt;
                }
            }
            catch { return null; }
        }

        private void BtnUploadPhotoToDb_Click(object sender, RoutedEventArgs e)
        {
            if (currentTable != "KURS_Lekarstva")
            {
                MessageBox.Show("Фото можно загружать только для лекарств.");
                return;
            }
            if (DgMain.SelectedItem == null) { MessageBox.Show("Выберите лекарство!"); return; }

            var dlg = new OpenFileDialog { Filter = "Изображения|*.jpg;*.jpeg;*.png;*.bmp" };
            if (dlg.ShowDialog() != true) return;

            try
            {
                byte[] imageBytes = File.ReadAllBytes(dlg.FileName);
                string fileName = System.IO.Path.GetFileName(dlg.FileName);

                var row = (DataRowView)DgMain.SelectedItem;
                int id = (int)row["id_lekarstva"];

                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    var cmd = new SqlCommand("UPDATE KURS_Lekarstva SET PhotoImage=@img, PhotoPath=@p WHERE id_lekarstva=@id", con);
                    cmd.Parameters.AddWithValue("@img", imageBytes);
                    cmd.Parameters.AddWithValue("@p", fileName);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Фото загружено в базу данных!");
                LoadData(currentTable);
            }
            catch (Exception ex) { MessageBox.Show("Ошибка загрузки фото: " + ex.Message); }
        }

        private void BtnShowReport_Click(object sender, RoutedEventArgs e)
        {
            if (DpFrom.SelectedDate == null || DpTo.SelectedDate == null)
            {
                MessageBox.Show("Выберите период!");
                return;
            }

            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string sql = @"SELECT z.id_zakaza as id_zakaza, z.data_sozdaniya as Дата, z.summa as Сумма,
                                          st.Nazvanie as Статус, u.Familiya + ' ' + u.Imya as Клиент
                                   FROM KURS_Zakazy z
                                   LEFT JOIN KURS_Status st ON z.id_statusa = st.id_statusa
                                   LEFT JOIN KURS_Polzovateli u ON z.id_klienta = u.id_polzovatelya
                                   WHERE CAST(z.data_sozdaniya as date) >= @from
                                     AND CAST(z.data_sozdaniya as date) <= @to
                                   ORDER BY z.data_sozdaniya";
                    var cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@from", DpFrom.SelectedDate.Value.Date);
                    cmd.Parameters.AddWithValue("@to", DpTo.SelectedDate.Value.Date);
                    var da = new SqlDataAdapter(cmd);
                    var dt = new DataTable();
                    da.Fill(dt);
                    DgReport.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        void ReturnOrderStock(int orderId)
        {
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    var cmdItems = new SqlCommand(
                        "SELECT id_lekarstva, Kolichestvo FROM KURS_Sostav_zakaza WHERE id_zakaza=@id", con);
                    cmdItems.Parameters.AddWithValue("@id", orderId);
                    using (var reader = cmdItems.ExecuteReader())
                    {
                        var medIds = new List<int>();
                        var qtys = new List<int>();
                        while (reader.Read())
                        {
                            medIds.Add((int)reader["id_lekarstva"]);
                            qtys.Add((int)reader["Kolichestvo"]);
                        }
                        reader.Close();

                        for (int i = 0; i < medIds.Count; i++)
                        {
                            var cmd = new SqlCommand(
                                "UPDATE KURS_Lekarstva SET Kolichestvo = Kolichestvo + @q WHERE id_lekarstva = @id",
                                con);
                            cmd.Parameters.AddWithValue("@q", qtys[i]);
                            cmd.Parameters.AddWithValue("@id", medIds[i]);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    var cmdDelItems = new SqlCommand(
                        "DELETE FROM KURS_Sostav_zakaza WHERE id_zakaza=@id", con);
                    cmdDelItems.Parameters.AddWithValue("@id", orderId);
                    cmdDelItems.ExecuteNonQuery();
                }
            }
            catch (Exception ex) { MessageBox.Show("Ошибка возврата остатков: " + ex.Message); }
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            this.Close();
        }
    }
}
