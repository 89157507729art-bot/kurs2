﻿using System;
using System.Data.SqlClient;
using System.Windows;

namespace KurkApteka
{
    public partial class MainWindow : Window
    {
        string ConnectString = DbHelper.ConnectionString;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Authorization_Button_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Login_Box.Text) || string.IsNullOrWhiteSpace(Password_Box1.Password))
            {
                MessageBox.Show("Введите логин и пароль!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    string query = "SELECT id_polzovatelya, id_roli FROM KURS_Polzovateli WHERE Login = @login AND Parol = @password";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@login", Login_Box.Text.Trim());
                        cmd.Parameters.AddWithValue("@password", Password_Box1.Password);

                        con.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int userId = reader.GetInt32(reader.GetOrdinal("id_polzovatelya"));
                                int roleId = reader.GetInt32(reader.GetOrdinal("id_roli"));

                                if (roleId == 3)
                                {
                                    new ClientWin(userId).Show();
                                    this.Close();
                                }
                                else if (roleId == 2)
                                {
                                    new EmployeeWin(userId).Show();
                                    this.Close();
                                }
                                else if (roleId == 1)
                                {
                                    new AdminWin().Show();
                                    this.Close();
                                }
                            }
                            else
                            {
                                MessageBox.Show("Неверный логин или пароль", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка авторизации: " + ex.Message);
            }
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            new RegisterWin().Show();
        }
    }
}
