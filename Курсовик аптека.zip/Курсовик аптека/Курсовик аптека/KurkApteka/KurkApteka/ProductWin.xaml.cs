using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace KurkApteka
{
    public partial class ProductWin : Window
    {
        int medicineId;
        int maxStock;
        List<int> cartIds;
        List<string> cartNames;
        List<decimal> cartPrices;
        List<int> cartQtys;

        string ConnectString = DbHelper.ConnectionString;

        public ProductWin(int medicineId, List<int> ids, List<string> names, List<decimal> prices, List<int> qtys, int maxStock)
        {
            InitializeComponent();
            this.medicineId = medicineId;
            this.maxStock = maxStock;
            this.cartIds = ids;
            this.cartNames = names;
            this.cartPrices = prices;
            this.cartQtys = qtys;
            LoadProduct();
        }

        void LoadProduct()
        {
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string sql = @"SELECT l.Nazvanie, l.Cena, l.Kolichestvo, l.Srok_godnosti,
                                          l.PhotoImage, l.PhotoPath,
                                          p.Nazvanie as Производитель
                                   FROM KURS_Lekarstva l
                                   LEFT JOIN KURS_Proizvoditeli p ON l.id_proizvoditelya = p.id_proizvoditelya
                                   WHERE l.id_lekarstva=@id";
                    using (var cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@id", medicineId);
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (!reader.Read()) return;

                            TbTitle.Text = reader["Nazvanie"].ToString();
                            decimal price = (decimal)reader["Cena"];
                            TbPrice.Text = price.ToString("N2") + " ₽";

                            TbManufacturer.Text = reader["Производитель"] == DBNull.Value
                                ? "Производитель не указан"
                                : "Производитель: " + reader["Производитель"];

                            int stock = (int)reader["Kolichestvo"];
                            TbStock.Text = stock > 0 ? "Остаток: " + stock + " шт." : "Нет в наличии";
                            TbStock.Foreground = stock > 0 ? Brushes.Gray : Brushes.Red;

                            if (reader["Srok_godnosti"] != DBNull.Value)
                                TbExpiry.Text = "Срок годности: " + ((DateTime)reader["Srok_godnosti"]).ToString("dd.MM.yyyy");

                            byte[] photoBytes = reader["PhotoImage"] == DBNull.Value ? null : (byte[])reader["PhotoImage"];
                            string photoPath = reader["PhotoPath"] == DBNull.Value ? "" : reader["PhotoPath"].ToString();

                            BitmapImage bmp = LoadImageFromBytes(photoBytes);
                            if (bmp != null)
                            {
                                ImgProduct.Source = bmp;
                            }
                            else if (!string.IsNullOrEmpty(photoPath))
                            {
                                string fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, photoPath);
                                if (File.Exists(fullPath))
                                    ImgProduct.Source = new BitmapImage(new Uri(fullPath));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки товара: " + ex.Message);
            }
        }

        BitmapImage LoadImageFromBytes(byte[] bytes)
        {
            if (bytes == null || bytes.Length == 0) return null;
            try
            {
                var bmp = new BitmapImage();
                using (var ms = new MemoryStream(bytes))
                {
                    bmp.BeginInit();
                    bmp.CacheOption = BitmapCacheOption.OnLoad;
                    bmp.StreamSource = ms;
                    bmp.EndInit();
                }
                bmp.Freeze();
                return bmp;
            }
            catch { return null; }
        }

        private void BtnAddToCart_Click(object sender, RoutedEventArgs e)
        {
            int qty = 1;
            try { qty = int.Parse(TbQty.Text); } catch { qty = 1; }

            if (qty < 1) qty = 1;
            if (qty > maxStock) qty = maxStock;

            // Проверяем, есть ли уже в корзине
            int idx = cartIds.IndexOf(medicineId);
            if (idx >= 0)
            {
                if (cartQtys[idx] + qty <= maxStock)
                    cartQtys[idx] += qty;
                else
                {
                    MessageBox.Show("Достигнут лимит остатков на складе!");
                    return;
                }
            }
            else
            {
                cartIds.Add(medicineId);
                cartNames.Add(TbTitle.Text);
                cartPrices.Add((decimal)0);
                cartQtys.Add(qty);
                // Узнаем цену из TbPrice
                string priceStr = TbPrice.Text.Replace(" ₽", "");
                decimal price = 0;
                try { price = decimal.Parse(priceStr); } catch { }
                cartPrices[cartPrices.Count - 1] = price;
            }

            MessageBox.Show("Товар добавлен в корзину!");
            this.Close();
        }
    }
}
