﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows;

namespace KurkApteka
{
    public static class SimpleApi
    {
        private static HttpListener _listener;
        private static Thread _thread;
        private static string ConnectString = DbHelper.ConnectionString;

        public static void Start()
        {
            _listener = new HttpListener();
            _listener.Prefixes.Add("http://localhost:54321/");
            try
            {
                _listener.Start();
                _thread = new Thread(ListenLoop);
                _thread.IsBackground = true;
                _thread.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось запустить API: " + ex.Message);
            }
        }

        public static void Stop()
        {
            try { _listener?.Stop(); } catch { }
            _thread?.Abort();
        }

        private static void ListenLoop()
        {
            while (_listener.IsListening)
            {
                try
                {
                    var context = _listener.GetContext();
                    var request = context.Request;
                    var response = context.Response;
                    response.AddHeader("Access-Control-Allow-Origin", "*");
                    response.AddHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");

                    if (request.HttpMethod == "OPTIONS")
                    {
                        response.StatusCode = 200;
                        response.Close();
                        continue;
                    }

                    string url = request.Url.AbsolutePath;

                    if (url == "/api/medicines" && request.HttpMethod == "GET")
                    {
                        string json = GetMedicinesJson();
                        SendJson(response, json);
                    }
                    else if (url.StartsWith("/api/medicines/") && request.HttpMethod == "GET")
                    {
                        string idStr = url.Substring(url.LastIndexOf('/') + 1);
                        if (int.TryParse(idStr, out int id))
                        {
                            string json = GetMedicineJson(id);
                            SendJson(response, json);
                        }
                        else
                        {
                            SendJson(response, "{\"error\":\"invalid id\"}", 400);
                        }
                    }
                    else if (url == "/api/statuses" && request.HttpMethod == "GET")
                    {
                        string json = GetStatusesJson();
                        SendJson(response, json);
                    }
                    else if (url == "/api/orders" && request.HttpMethod == "GET")
                    {
                        string clientIdStr = request.QueryString["clientId"];
                        if (int.TryParse(clientIdStr, out int clientId))
                        {
                            string json = GetOrdersJson(clientId);
                            SendJson(response, json);
                        }
                        else
                        {
                            SendJson(response, "{\"error\":\"clientId required\"}", 400);
                        }
                    }
                    else
                    {
                        response.StatusCode = 404;
                        response.Close();
                    }
                }
                catch { }
            }
        }

        private static void SendJson(HttpListenerResponse response, string json, int statusCode = 200)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(json);
            response.ContentType = "application/json";
            response.StatusCode = statusCode;
            response.ContentLength64 = buffer.Length;
            response.OutputStream.Write(buffer, 0, buffer.Length);
            response.OutputStream.Close();
        }

        // ---------- Методы работы с БД ----------

        private static string GetMedicinesJson()
        {
            var sb = new StringBuilder();
            sb.Append("[");
            bool first = true;
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string sql = @"SELECT l.id_lekarstva, l.Nazvanie, l.Cena, l.Kolichestvo,
                                        ISNULL(k.Nazvanie,'') as Категория,
                                        ISNULL(p.Nazvanie,'') as Производитель,
                                        l.PhotoPath
                                 FROM KURS_Lekarstva l
                                 LEFT JOIN KURS_Kategorii k ON l.id_kategorii=k.id_kategorii
                                 LEFT JOIN KURS_Proizvoditeli p ON l.id_proizvoditelya=p.id_proizvoditelya";
                    using (var cmd = new SqlCommand(sql, con))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            if (!first) sb.Append(",");
                            first = false;
                            sb.Append("{");
                            sb.AppendFormat("\"id\":{0},\"nazvanie\":\"{1}\",\"cena\":{2},\"kolichestvo\":{3},\"kategorija\":\"{4}\",\"proizvoditel\":\"{5}\",\"photopath\":\"{6}\"",
                                reader["id_lekarstva"], EscapeJson(reader["Nazvanie"].ToString()),
                                reader["Cena"], reader["Kolichestvo"],
                                EscapeJson(reader["Категория"].ToString()),
                                EscapeJson(reader["Производитель"].ToString()),
                                EscapeJson(reader["PhotoPath"] == DBNull.Value ? "" : reader["PhotoPath"].ToString()));
                            sb.Append("}");
                        }
                    }
                }
            }
            catch { }
            sb.Append("]");
            return sb.ToString();
        }

        private static string GetMedicineJson(int id)
        {
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string sql = @"SELECT l.id_lekarstva, l.Nazvanie, l.Cena, l.Kolichestvo,
                                        ISNULL(k.Nazvanie,'') as Категория,
                                        ISNULL(p.Nazvanie,'') as Производитель,
                                        l.PhotoPath
                                 FROM KURS_Lekarstva l
                                 LEFT JOIN KURS_Kategorii k ON l.id_kategorii=k.id_kategorii
                                 LEFT JOIN KURS_Proizvoditeli p ON l.id_proizvoditelya=p.id_proizvoditelya
                                 WHERE l.id_lekarstva=@id";
                    using (var cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return string.Format("{{\"id\":{0},\"nazvanie\":\"{1}\",\"cena\":{2},\"kolichestvo\":{3},\"kategorija\":\"{4}\",\"proizvoditel\":\"{5}\",\"photopath\":\"{6}\"}}",
                                    reader["id_lekarstva"], EscapeJson(reader["Nazvanie"].ToString()),
                                    reader["Cena"], reader["Kolichestvo"],
                                    EscapeJson(reader["Категория"].ToString()),
                                    EscapeJson(reader["Производитель"].ToString()),
                                    EscapeJson(reader["PhotoPath"] == DBNull.Value ? "" : reader["PhotoPath"].ToString()));
                            }
                        }
                    }
                }
            }
            catch { }
            return "{\"error\":\"not found\"}";
        }

        private static string GetStatusesJson()
        {
            var sb = new StringBuilder();
            sb.Append("[");
            bool first = true;
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    using (var cmd = new SqlCommand("SELECT id_statusa, Nazvanie FROM KURS_Status", con))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            if (!first) sb.Append(",");
                            first = false;
                            sb.AppendFormat("{{\"id_statusa\":{0},\"nazvanie\":\"{1}\"}}",
                                reader["id_statusa"], EscapeJson(reader["Nazvanie"].ToString()));
                        }
                    }
                }
            }
            catch { }
            sb.Append("]");
            return sb.ToString();
        }

        private static string GetOrdersJson(int clientId)
        {
            var sb = new StringBuilder();
            sb.Append("[");
            bool first = true;
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string sql = @"SELECT z.id_zakaza, z.data_sozdaniya, z.summa,
                                        ISNULL(s.Nazvanie,'') as Статус
                                 FROM KURS_Zakazy z
                                 LEFT JOIN KURS_Status s ON z.id_statusa=s.id_statusa
                                 WHERE z.id_klienta=@c
                                 ORDER BY z.id_zakaza DESC";
                    using (var cmd = new SqlCommand(sql, con))
                    {
                        cmd.Parameters.AddWithValue("@c", clientId);
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                if (!first) sb.Append(",");
                                first = false;
                                sb.AppendFormat("{{\"id_zakaza\":{0},\"data\":\"{1}\",\"summa\":{2},\"status\":\"{3}\"}}",
                                    reader["id_zakaza"], ((DateTime)reader["data_sozdaniya"]).ToString("dd.MM.yyyy HH:mm"),
                                    reader["summa"], EscapeJson(reader["Статус"].ToString()));
                            }
                        }
                    }
                }
            }
            catch { }
            sb.Append("]");
            return sb.ToString();
        }

        private static string EscapeJson(string s)
        {
            if (s == null) return "";
            return s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "\\r");
        }

        private class StringBuilder
        {
            private System.Text.StringBuilder _sb = new System.Text.StringBuilder();
            public StringBuilder Append(string s) { _sb.Append(s); return this; }
            public StringBuilder AppendFormat(string fmt, params object[] args) { _sb.AppendFormat(fmt, args); return this; }
            public override string ToString() { return _sb.ToString(); }
        }
    }
}