using System;
using System.Data.SqlClient;
using System.Windows;

namespace KurkApteka
{
    public partial class RegisterWin : Window
    {
        string ConnectString = DbHelper.ConnectionString;

        public RegisterWin()
        {
            InitializeComponent();
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TbLogin.Text) ||
                string.IsNullOrWhiteSpace(PbPassword.Password) ||
                string.IsNullOrWhiteSpace(TbFamiliya.Text) ||
                string.IsNullOrWhiteSpace(TbImya.Text))
            {
                MessageBox.Show("Заполните обязательные поля: логин, пароль, фамилию, имя.");
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    // Проверяем, не занят ли логин
                    SqlCommand cmdCheck = new SqlCommand(
                        "SELECT COUNT(*) FROM KURS_Polzovateli WHERE Login=@login", con);
                    cmdCheck.Parameters.AddWithValue("@login", TbLogin.Text.Trim());
                    int count = (int)cmdCheck.ExecuteScalar();
                    if (count > 0)
                    {
                        MessageBox.Show("Такой логин уже существует!");
                        return;
                    }

                    // id_roli = 3 — клиент
                    SqlCommand cmd = new SqlCommand(
                        @"INSERT INTO KURS_Polzovateli (id_roli, Login, Parol, Telefon, email, adres, Familiya, Imya, Otchestvo)
                          VALUES (3, @login, @pass, @tel, @email, @addr, @fam, @im, @otch)", con);
                    cmd.Parameters.AddWithValue("@login", TbLogin.Text.Trim());
                    cmd.Parameters.AddWithValue("@pass", PbPassword.Password);
                    cmd.Parameters.AddWithValue("@tel", TbTelefon.Text.Trim());
                    cmd.Parameters.AddWithValue("@email", TbEmail.Text.Trim());
                    cmd.Parameters.AddWithValue("@addr", TbAdres.Text.Trim());
                    cmd.Parameters.AddWithValue("@fam", TbFamiliya.Text.Trim());
                    cmd.Parameters.AddWithValue("@im", TbImya.Text.Trim());
                    cmd.Parameters.AddWithValue("@otch", TbOtchestvo.Text.Trim());
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Регистрация прошла успешно! Теперь вы можете войти.");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка регистрации: " + ex.Message);
            }
        }
    }
}
