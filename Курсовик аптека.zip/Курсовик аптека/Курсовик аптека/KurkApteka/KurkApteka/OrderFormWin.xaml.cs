using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows;

namespace KurkApteka
{
    public partial class OrderFormWin : Window
    {
        int userId;
        decimal totalSum;
        List<int> cartIds;
        List<int> cartQtys;
        List<decimal> cartPrices;

        string ConnectString = DbHelper.ConnectionString;

        public OrderFormWin(int userId, List<int> ids, List<int> qtys, List<decimal> prices, decimal total)
        {
            InitializeComponent();
            this.userId = userId;
            this.cartIds = ids;
            this.cartQtys = qtys;
            this.cartPrices = prices;
            this.totalSum = total;
            LblTotal.Text = "ИТОГО: " + total.ToString("N2") + " ₽";
        }

        private void BtnCheckout_Click(object sender, RoutedEventArgs e)
        {
            // Валидация
            if (string.IsNullOrWhiteSpace(TbPhone.Text))
            {
                MessageBox.Show("Введите номер телефона!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                TbPhone.Focus();
                return;
            }
            if (!Regex.IsMatch(TbPhone.Text, @"^\+?[0-9\s\-\(\)]{7,}$"))
            {
                MessageBox.Show("Некорректный номер телефона!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                TbPhone.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(TbCard.Text))
            {
                MessageBox.Show("Введите номер карты!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                TbCard.Focus();
                return;
            }
            if (!Regex.IsMatch(TbCard.Text, @"^[0-9\s]{13,19}$"))
            {
                MessageBox.Show("Некорректный номер карты!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                TbCard.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(TbEmail.Text))
            {
                MessageBox.Show("Введите email!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                TbEmail.Focus();
                return;
            }
            if (!Regex.IsMatch(TbEmail.Text, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Некорректный email!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                TbEmail.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(TbAddress.Text))
            {
                MessageBox.Show("Введите адрес доставки!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                TbAddress.Focus();
                return;
            }

            // Сохраняем заказ в БД
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    using (var tr = con.BeginTransaction())
                    {
                        try
                        {
                            // 1. Создаём заказ
                            var cmdOrder = new SqlCommand(
                                @"INSERT INTO KURS_Zakazy (id_klienta, id_farmacevta, data_sozdaniya, summa, id_statusa)
                                  OUTPUT INSERTED.id_zakaza
                                  VALUES (@c, NULL, GETDATE(), @s, 1)", con, tr);
                            cmdOrder.Parameters.AddWithValue("@c", userId);
                            cmdOrder.Parameters.AddWithValue("@s", totalSum);
                            int newOrderId = (int)cmdOrder.ExecuteScalar();

                            // 2. Состав заказа + списание остатков
                            for (int i = 0; i < cartIds.Count; i++)
                            {
                                var cmdItem = new SqlCommand(
                                    @"INSERT INTO KURS_Sostav_zakaza (id_zakaza, id_lekarstva, Kolichestvo, Cena_pri_zakaze)
                                      VALUES (@o, @m, @q, @p)", con, tr);
                                cmdItem.Parameters.AddWithValue("@o", newOrderId);
                                cmdItem.Parameters.AddWithValue("@m", cartIds[i]);
                                cmdItem.Parameters.AddWithValue("@q", cartQtys[i]);
                                cmdItem.Parameters.AddWithValue("@p", cartPrices[i]);
                                cmdItem.ExecuteNonQuery();

                                var cmdStock = new SqlCommand(
                                    "UPDATE KURS_Lekarstva SET Kolichestvo = Kolichestvo - @q WHERE id_lekarstva = @m",
                                    con, tr);
                                cmdStock.Parameters.AddWithValue("@q", cartQtys[i]);
                                cmdStock.Parameters.AddWithValue("@m", cartIds[i]);
                                cmdStock.ExecuteNonQuery();
                            }

                            tr.Commit();
                            MessageBox.Show("Заказ №" + newOrderId + " успешно оформлен!");
                            DialogResult = true;
                            Close();
                        }
                        catch (Exception ex)
                        {
                            tr.Rollback();
                            MessageBox.Show("Ошибка оформления: " + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
