namespace KurkApteka
{
    public static class DbHelper
    {
        public static string ConnectionString
        {
            get
            {
                return @"Server=stud-mssql.sttec.yar.ru,38325;Database=user89_db;User Id=user89_db;Password=user89;";
            }
        }
    }
}
