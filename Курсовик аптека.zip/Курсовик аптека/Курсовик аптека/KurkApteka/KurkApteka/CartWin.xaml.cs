using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace KurkApteka
{
    public partial class CartWin : Window
    {
        List<int> cartIds;
        List<int> cartQtys;
        List<string> cartNames;
        List<decimal> cartPrices;
        int userId;

        string ConnectString = DbHelper.ConnectionString;

        public CartWin(List<string> lines, List<int> ids, List<int> qtys, int userId)
        {
            InitializeComponent();
            this.cartIds = ids;
            this.cartQtys = qtys;
            this.cartNames = new List<string>();
            this.cartPrices = new List<decimal>();
            this.userId = userId;

            foreach (var line in lines)
            {
                var parts = line.Split(new[] { " — " }, StringSplitOptions.None);
                var namePart = parts[0];
                var pricePart = parts[1].Split(new[] { " ₽ x " }, StringSplitOptions.None)[0];
                var price = decimal.Parse(pricePart);
                cartNames.Add(namePart);
                cartPrices.Add(price);
            }

            Refresh();
        }

        void Refresh()
        {
            LbCart.Items.Clear();
            decimal total = 0;
            for (int i = 0; i < cartIds.Count; i++)
            {
                decimal itemTotal = cartPrices[i] * cartQtys[i];
                total += itemTotal;
                LbCart.Items.Add(new
                {
                    Id = cartIds[i],
                    Name = cartNames[i],
                    Price = cartPrices[i],
                    Qty = cartQtys[i],
                    Total = itemTotal
                });
            }
            LblTotal.Text = total.ToString("N2") + " ₽";
        }

        private void BtnRemove_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button)
            {
                Button btn = (Button)sender;
                if (btn.Tag != null)
                {
                    int id = (int)btn.Tag;
                    int idx = cartIds.IndexOf(id);
                    if (idx >= 0)
                    {
                        cartIds.RemoveAt(idx);
                        cartQtys.RemoveAt(idx);
                        cartNames.RemoveAt(idx);
                        cartPrices.RemoveAt(idx);
                        Refresh();
                    }
                }
            }
        }

        private void BtnCheckout_Click(object sender, RoutedEventArgs e)
        {
            if (cartIds.Count == 0)
            {
                MessageBox.Show("Корзина пуста!");
                return;
            }

            decimal totalSum = 0;
            for (int i = 0; i < cartIds.Count; i++)
                totalSum += cartPrices[i] * cartQtys[i];

            var orderForm = new OrderFormWin(userId, cartIds, cartQtys, cartPrices, totalSum);
            if (orderForm.ShowDialog() == true)
            {
                cartIds.Clear();
                cartQtys.Clear();
                cartNames.Clear();
                cartPrices.Clear();
                Refresh();
                this.Close();
            }
        }
    }
}
