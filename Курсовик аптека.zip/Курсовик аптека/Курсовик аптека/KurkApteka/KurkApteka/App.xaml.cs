﻿using System;
using System.Windows;

namespace KurkApteka
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            SimpleApi.Start();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            SimpleApi.Stop();
            base.OnExit(e);
        }
    }
}