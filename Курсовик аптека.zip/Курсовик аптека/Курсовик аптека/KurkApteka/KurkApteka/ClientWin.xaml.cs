﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace KurkApteka
{
    public partial class ClientWin : Window
    {
        string ConnectString = DbHelper.ConnectionString;
        int userId = 0;
        int currentRazdelId = 0;

        // Корзина: простые списки
        List<int> cartIds = new List<int>();
        List<string> cartNames = new List<string>();
        List<decimal> cartPrices = new List<decimal>();
        List<int> cartQtys = new List<int>();

        public ClientWin(int id)
        {
            InitializeComponent();
            userId = id;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadFio();
            LoadRazdely();
        }

        void LoadFio()
        {
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    var cmd = new SqlCommand("SELECT Familiya + ' ' + Imya FROM KURS_Polzovateli WHERE id_polzovatelya=@id", con);
                    cmd.Parameters.AddWithValue("@id", userId);
                    var res = cmd.ExecuteScalar();
                    if (res != null) LblFio.Text = res.ToString();
                }
            }
            catch { }
        }

        void LoadRazdely()
        {
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    var da = new SqlDataAdapter("SELECT id_razdel, Nazvanie FROM KURS_Razdel", con);
                    var dt = new DataTable();
                    da.Fill(dt);

                    var allRow = dt.NewRow();
                    allRow["id_razdel"] = 0;
                    allRow["Nazvanie"] = "Все лекарства";
                    dt.Rows.InsertAt(allRow, 0);

                    LbRazdely.ItemsSource = dt.DefaultView;
                    LbRazdely.SelectedValuePath = "id_razdel";
                    LbRazdely.SelectedIndex = 0;
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void LbRazdely_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (LbRazdely.SelectedValue == null) return;
            currentRazdelId = (int)LbRazdely.SelectedValue;
            if (TbSelectedRazdel != null)
                TbSelectedRazdel.Text = ((DataRowView)LbRazdely.SelectedItem)["Nazvanie"].ToString();

            LoadCategories(currentRazdelId == 0 ? null : (int?)currentRazdelId);
            LoadMedicines(currentRazdelId == 0 ? 0 : currentRazdelId, null);
        }

        void LoadCategories(int? razdelId)
        {
            WpCategories.Children.Clear();
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string query = "SELECT id_kategorii, Nazvanie FROM KURS_Kategorii";
                    if (razdelId.HasValue) query += " WHERE id_razdel = @r";
                    var cmd = new SqlCommand(query, con);
                    if (razdelId.HasValue) cmd.Parameters.AddWithValue("@r", razdelId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var btn = new Button
                            {
                                Content = reader["Nazvanie"].ToString(),
                                Tag = reader["id_kategorii"],
                                Background = new SolidColorBrush(Color.FromRgb(232, 245, 233)),
                                Foreground = new SolidColorBrush(Color.FromRgb(46, 125, 50)),
                                BorderThickness = new Thickness(0),
                                Padding = new Thickness(14, 8, 14, 8),
                                Margin = new Thickness(0, 0, 10, 10),
                                FontSize = 14,
                                Cursor = System.Windows.Input.Cursors.Hand
                            };
                            btn.Click += Category_Click;
                            WpCategories.Children.Add(btn);
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void Category_Click(object sender, RoutedEventArgs e)
        {
            int catId = (int)((Button)sender).Tag;
            LoadMedicines(currentRazdelId, catId);
        }

        void LoadMedicines(int razdelId, int? categoryId, string searchText = "")
        {
            WpMedicines.Children.Clear();
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string sql = @"SELECT l.id_lekarstva, l.Nazvanie, l.Cena, l.Kolichestvo,
                                          l.PhotoImage, l.PhotoPath
                                   FROM KURS_Lekarstva l
                                   WHERE 1=1";

                    if (razdelId > 0) sql += " AND l.id_razdel = @r";
                    if (categoryId.HasValue) sql += " AND l.id_kategorii = @c";
                    if (!string.IsNullOrWhiteSpace(searchText)) sql += " AND l.Nazvanie LIKE @search";

                    var cmd = new SqlCommand(sql, con);
                    if (razdelId > 0) cmd.Parameters.AddWithValue("@r", razdelId);
                    if (categoryId.HasValue) cmd.Parameters.AddWithValue("@c", categoryId);
                    if (!string.IsNullOrWhiteSpace(searchText))
                        cmd.Parameters.AddWithValue("@search", "%" + searchText + "%");

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int id = (int)reader["id_lekarstva"];
                            string name = reader["Nazvanie"].ToString();
                            decimal cena = (decimal)reader["Cena"];
                            int stock = (int)reader["Kolichestvo"];
                            byte[] photoBytes = reader["PhotoImage"] == DBNull.Value ? null : (byte[])reader["PhotoImage"];
                            string photoPath = reader["PhotoPath"] == DBNull.Value ? "" : reader["PhotoPath"].ToString();

                            var card = BuildCard(id, name, cena, stock, photoBytes, photoPath);
                            WpMedicines.Children.Add(card);
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        Border BuildCard(int id, string name, decimal price, int stock, byte[] photoBytes, string photoPath)
        {
            var card = new Border
            {
                Width = 240,
                Height = 430,
                Margin = new Thickness(0, 0, 18, 18),
                Background = Brushes.White,
                CornerRadius = new CornerRadius(12),
                BorderBrush = new SolidColorBrush(Color.FromRgb(224, 224, 224)),
                BorderThickness = new Thickness(1),
                Tag = id,
                Cursor = System.Windows.Input.Cursors.Hand
            };
            card.MouseLeftButtonUp += (s, ev) =>
            {
                var prod = new ProductWin(id, cartIds, cartNames, cartPrices, cartQtys, stock);
                prod.ShowDialog();
                LblCartCount.Text = GetCartTotalQty().ToString();
                LoadMedicines(currentRazdelId == 0 ? 0 : currentRazdelId, null, TbSearch.Text.Trim());
            };

            var sp = new StackPanel { Margin = new Thickness(14) };

            // Фото (из БД или файла)
            var imgBorder = new Border
            {
                Height = 180,
                Background = new SolidColorBrush(Color.FromRgb(245, 245, 245)),
                CornerRadius = new CornerRadius(8),
                Margin = new Thickness(0, 0, 0, 10)
            };
            BitmapImage bmp = LoadImageFromBytes(photoBytes);
            if (bmp != null)
            {
                var img = new Image { Stretch = Stretch.Uniform };
                img.Source = bmp;
                imgBorder.Child = img;
            }
            else if (!string.IsNullOrEmpty(photoPath))
            {
                string fullPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, photoPath);
                if (File.Exists(fullPath))
                {
                    var img = new Image { Stretch = Stretch.Uniform };
                    img.Source = new BitmapImage(new Uri(fullPath));
                    imgBorder.Child = img;
                }
                else
                    imgBorder.Child = new TextBlock { Text = "Нет фото", HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Foreground = Brushes.Gray };
            }
            else
                imgBorder.Child = new TextBlock { Text = "Нет фото", HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Foreground = Brushes.Gray };
            sp.Children.Add(imgBorder);

            // Название
            sp.Children.Add(new TextBlock
            {
                Text = name, FontWeight = FontWeights.Bold, FontSize = 15,
                TextWrapping = TextWrapping.Wrap, Height = 50, Margin = new Thickness(0, 0, 0, 6)
            });

            // Цена
            sp.Children.Add(new TextBlock
            {
                Text = price.ToString("N2") + " ₽", FontWeight = FontWeights.Bold,
                FontSize = 20, Foreground = new SolidColorBrush(Color.FromRgb(46, 125, 50)),
                Margin = new Thickness(0, 0, 0, 8)
            });

            // Остаток
            sp.Children.Add(new TextBlock
            {
                Text = stock > 0 ? "В наличии: " + stock + " шт." : "Нет в наличии",
                FontSize = 12,
                Foreground = stock > 0 ? Brushes.Gray : Brushes.Red,
                Margin = new Thickness(0, 0, 0, 12)
            });

            // Кнопка
            var btnBuy = new Button
            {
                Content = "В корзину",
                Background = new SolidColorBrush(Color.FromRgb(46, 125, 50)),
                Foreground = Brushes.White,
                BorderThickness = new Thickness(0),
                Padding = new Thickness(0, 10, 0, 10),
                Cursor = System.Windows.Input.Cursors.Hand,
                IsEnabled = stock > 0,
                Tag = id
            };
            btnBuy.Click += (s, ev) => AddToCart(id, name, price, 1);
            sp.Children.Add(btnBuy);

            card.Child = sp;
            return card;
        }

        BitmapImage LoadImageFromBytes(byte[] bytes)
        {
            if (bytes == null || bytes.Length == 0) return null;
            try
            {
                var bmp = new BitmapImage();
                using (var ms = new MemoryStream(bytes))
                {
                    bmp.BeginInit();
                    bmp.CacheOption = BitmapCacheOption.OnLoad;
                    bmp.StreamSource = ms;
                    bmp.EndInit();
                }
                bmp.Freeze();
                return bmp;
            }
            catch { return null; }
        }

        private void TbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TbSearch.Text))
                LoadMedicines(currentRazdelId == 0 ? 0 : currentRazdelId, null);
            else
                LoadMedicines(0, null, TbSearch.Text.Trim());
        }

        void AddToCart(int medicineId, string name, decimal price, int qty)
        {
            int stock = 0;
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    var cmd = new SqlCommand("SELECT Kolichestvo FROM KURS_Lekarstva WHERE id_lekarstva=@id", con);
                    cmd.Parameters.AddWithValue("@id", medicineId);
                    stock = (int)cmd.ExecuteScalar();
                }
            }
            catch { }

            if (stock <= 0)
            {
                MessageBox.Show("Товара нет в наличии!");
                return;
            }

            int idx = cartIds.IndexOf(medicineId);
            if (idx >= 0)
            {
                if (cartQtys[idx] + qty <= stock) cartQtys[idx] += qty;
                else MessageBox.Show("Достигнут лимит остатков на складе!");
            }
            else
            {
                if (qty > stock) qty = stock;
                cartIds.Add(medicineId);
                cartNames.Add(name);
                cartPrices.Add(price);
                cartQtys.Add(qty);
            }

            LblCartCount.Text = GetCartTotalQty().ToString();
            MessageBox.Show("Товар добавлен в корзину!");
        }

        int GetCartTotalQty()
        {
            int s = 0;
            foreach (var q in cartQtys) s += q;
            return s;
        }

        private void BtnCart_Click(object sender, RoutedEventArgs e)
        {
            var lines = new List<string>();
            for (int i = 0; i < cartIds.Count; i++)
                lines.Add(cartNames[i] + " — " + cartPrices[i].ToString("N2") + " ₽ x " + cartQtys[i] + " = " + (cartPrices[i] * cartQtys[i]).ToString("N2") + " ₽");

            new CartWin(lines, cartIds, cartQtys, userId).ShowDialog();
            LblCartCount.Text = GetCartTotalQty().ToString();
            LoadMedicines(currentRazdelId == 0 ? 0 : currentRazdelId, null, TbSearch.Text.Trim());
        }

        private void BtnOrders_Click(object sender, RoutedEventArgs e)
        {
            new OrdersWin(userId).ShowDialog();
        }

        private void BtnProfile_Click(object sender, RoutedEventArgs e)
        {
            new ProfileWin(userId).ShowDialog();
            LoadFio();
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            this.Close();
        }
    }
}
