using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace KurkApteka
{
    public partial class OrdersWin : Window
    {
        int userId;
        string ConnectString = DbHelper.ConnectionString;

        public OrdersWin(int userId)
        {
            InitializeComponent();
            this.userId = userId;
            LoadOrders();
        }

        void LoadOrders()
        {
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string sql = @"SELECT z.id_zakaza, z.data_sozdaniya, z.summa, s.Nazvanie
                                   FROM KURS_Zakazy z
                                   LEFT JOIN KURS_Status s ON z.id_statusa = s.id_statusa
                                   WHERE z.id_klienta = @id
                                   ORDER BY z.id_zakaza DESC";
                    var cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@id", userId);
                    var da = new SqlDataAdapter(cmd);
                    var dt = new DataTable();
                    da.Fill(dt);
                    DgOrders.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        void ReturnOrderStock(int orderId)
        {
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    var cmdItems = new SqlCommand(
                        "SELECT id_lekarstva, Kolichestvo FROM KURS_Sostav_zakaza WHERE id_zakaza=@id", con);
                    cmdItems.Parameters.AddWithValue("@id", orderId);
                    using (var reader = cmdItems.ExecuteReader())
                    {
                        var medIds = new List<int>();
                        var qtys = new List<int>();
                        while (reader.Read())
                        {
                            medIds.Add((int)reader["id_lekarstva"]);
                            qtys.Add((int)reader["Kolichestvo"]);
                        }
                        reader.Close();

                        for (int i = 0; i < medIds.Count; i++)
                        {
                            var cmd = new SqlCommand(
                                "UPDATE KURS_Lekarstva SET Kolichestvo = Kolichestvo + @q WHERE id_lekarstva = @id",
                                con);
                            cmd.Parameters.AddWithValue("@q", qtys[i]);
                            cmd.Parameters.AddWithValue("@id", medIds[i]);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    var cmdDelItems = new SqlCommand(
                        "DELETE FROM KURS_Sostav_zakaza WHERE id_zakaza=@id", con);
                    cmdDelItems.Parameters.AddWithValue("@id", orderId);
                    cmdDelItems.ExecuteNonQuery();
                }
            }
            catch (Exception ex) { MessageBox.Show("Ошибка возврата остатков: " + ex.Message); }
        }

        private void BtnDeleteOrder_Click(object sender, RoutedEventArgs e)
        {
            if (DgOrders.SelectedItem == null) { MessageBox.Show("Выберите заказ!"); return; }
            var row = (DataRowView)DgOrders.SelectedItem;
            int orderId = (int)row["id_zakaza"];
            string status = row["Nazvanie"] == DBNull.Value ? "" : row["Nazvanie"].ToString();

            if (status == "Доставлен" || status == "Отменён")
            {
                MessageBox.Show("Нельзя отменить заказ со статусом: " + status);
                return;
            }

            if (MessageBox.Show("Отменить заказ №" + orderId + " и вернуть остатки на склад?",
                    "Подтверждение", MessageBoxButton.YesNo) != MessageBoxResult.Yes)
                return;

            try
            {
                ReturnOrderStock(orderId);

                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    var cmd = new SqlCommand("DELETE FROM KURS_Zakazy WHERE id_zakaza=@id", con);
                    cmd.Parameters.AddWithValue("@id", orderId);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Заказ отменён, остатки возвращены на склад!");
                LoadOrders();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        // Двойной клик — показать детали заказа
        private void DgOrders_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (DgOrders.SelectedItem == null) return;
            var row = (DataRowView)DgOrders.SelectedItem;
            int orderId = (int)row["id_zakaza"];
            string orderDate = row["data_sozdaniya"] == DBNull.Value ? "" : ((DateTime)row["data_sozdaniya"]).ToString("dd.MM.yyyy HH:mm");
            decimal totalSum = row["summa"] == DBNull.Value ? 0 : (decimal)row["summa"];

            new OrderDetailsWin(orderId, orderDate, totalSum).ShowDialog();
        }

        private void DgOrders_MouseLeftButtonUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            // Подсветка строки при клике
        }
    }
}
