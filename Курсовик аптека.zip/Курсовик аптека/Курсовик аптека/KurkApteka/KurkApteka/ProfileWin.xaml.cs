using System;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows;

namespace KurkApteka
{
    public partial class ProfileWin : Window
    {
        int userId;
        string ConnectString = DbHelper.ConnectionString;

        public ProfileWin(int userId)
        {
            InitializeComponent();
            this.userId = userId;
            LoadData();
        }

        void LoadData()
        {
            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    var cmd = new SqlCommand(
                        "SELECT Login, Familiya, Imya, Otchestvo, Telefon, email, adres FROM KURS_Polzovateli WHERE id_polzovatelya=@id", con);
                    cmd.Parameters.AddWithValue("@id", userId);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            TbLogin.Text = reader["Login"].ToString();
                            TbFamiliya.Text = reader["Familiya"] == DBNull.Value ? "" : reader["Familiya"].ToString();
                            TbImya.Text = reader["Imya"] == DBNull.Value ? "" : reader["Imya"].ToString();
                            TbOtchestvo.Text = reader["Otchestvo"] == DBNull.Value ? "" : reader["Otchestvo"].ToString();
                            TbTelefon.Text = reader["Telefon"] == DBNull.Value ? "" : reader["Telefon"].ToString();
                            TbEmail.Text = reader["email"] == DBNull.Value ? "" : reader["email"].ToString();
                            TbAdres.Text = reader["adres"] == DBNull.Value ? "" : reader["adres"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TbFamiliya.Text) || string.IsNullOrWhiteSpace(TbImya.Text))
            {
                MessageBox.Show("Заполните фамилию и имя!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!string.IsNullOrWhiteSpace(TbEmail.Text) && !Regex.IsMatch(TbEmail.Text, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Некорректный email!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                TbEmail.Focus();
                return;
            }

            try
            {
                using (var con = new SqlConnection(ConnectString))
                {
                    con.Open();
                    string sql = @"UPDATE KURS_Polzovateli SET Familiya=@fam, Imya=@im, Otchestvo=@otch,
                                      Telefon=@tel, email=@email, adres=@addr WHERE id_polzovatelya=@id";
                    var cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@fam", TbFamiliya.Text.Trim());
                    cmd.Parameters.AddWithValue("@im", TbImya.Text.Trim());
                    cmd.Parameters.AddWithValue("@otch", string.IsNullOrWhiteSpace(TbOtchestvo.Text) ? (object)DBNull.Value : TbOtchestvo.Text.Trim());
                    cmd.Parameters.AddWithValue("@tel", string.IsNullOrWhiteSpace(TbTelefon.Text) ? (object)DBNull.Value : TbTelefon.Text.Trim());
                    cmd.Parameters.AddWithValue("@email", string.IsNullOrWhiteSpace(TbEmail.Text) ? (object)DBNull.Value : TbEmail.Text.Trim());
                    cmd.Parameters.AddWithValue("@addr", string.IsNullOrWhiteSpace(TbAdres.Text) ? (object)DBNull.Value : TbAdres.Text.Trim());
                    cmd.Parameters.AddWithValue("@id", userId);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Данные обновлены!");
                DialogResult = true;
                Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }
}
